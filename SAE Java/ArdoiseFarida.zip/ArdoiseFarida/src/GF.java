import java.util.ArrayList;
import ardoise.*;

public class GF extends Forme {
	
	private ArrayList<Forme> formes;
	
	public GF() {
		super();
		formes = new ArrayList<Forme>();
	}
	
	public void ajouterForme(Forme forme) {
		try {
            if (forme != null) {
                formes.add(forme);
            } else {
                throw new IllegalArgumentException("La forme à ajouter ne peut pas être null.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Erreur lors de l'ajout d'une forme à l'ardoise : " + e.getMessage());
        }
		 
	    }
	

	
	@Override
	public void deplacer(int deplacementX, int deplacementY) {
		for (Forme forme : formes) {
            try {
                forme.deplacer(deplacementX, deplacementY);
            } catch (Exception e) {
                System.out.println("Erreur lors du déplacement d'une forme composante : " + e.getMessage());
            }
            }
	        }
	
	@Override
	public ArrayList<Segment> dessiner() {
		ArrayList<Segment> segments = new ArrayList<Segment>();
		try {
		for (int i = 0; i < formes.size(); i++) {
			segments.addAll(formes.get(i).dessiner());
		}
		} catch (Exception e) {
            System.out.println("Erreur lors du dessin d'une forme composante : " + e.getMessage());
        }
		return segments;
	}

	@Override
	public String typeForme() {
		return "GF";
	}
}