import java.util.ArrayList;
import ardoise.*;

public class Triangles extends Forme {
	
	private PointPlan p1;
    private PointPlan p2;
    private PointPlan p3;
    
    public Triangles() {
		super();
	}
    public Triangles(String nomForme, PointPlan p1, PointPlan p2, PointPlan p3) {
    	super(nomForme);
    	try {
            if ((p1.equals(p2) || p2.equals(p3) || p3.equals(p1))||(p1==null || p2==null||p3==null) ) {
                throw new IllegalArgumentException("Les points fournis ne forment pas un chapeau valide.");
            }
            this.p1 = p1;
            this.p2 = p2;
            this.p3 = p3;
        } catch (IllegalArgumentException e) {
            System.out.println("Erreur lors de la création d'une forme : " + e.getMessage());
        }
    
    }
	@Override
	public void deplacer(int deplacementX, int deplacementY) {
		 try {
	            if (deplacementX < 0 || deplacementY < 0) {
	                throw new IllegalArgumentException("Les valeurs de déplacement doivent être positives.");
	            }
	            p1.deplacer(deplacementX, deplacementY);
	            p2.deplacer(deplacementX, deplacementY);
	            p3.deplacer(deplacementX, deplacementY);
	        } catch (IllegalArgumentException e) {
	            
	            System.out.println("Erreur lors du déplacement du Quadrilatère : " + e.getMessage());
	        }
		
	}
	
	@Override
	public ArrayList<Segment> dessiner() {
		ArrayList<Segment> segments = new ArrayList<>();
		 try {
	            segments.add(new Segment(p1, p2));
	            segments.add(new Segment(p2, p3));
	            segments.add(new Segment(p3, p1));
	        } catch (Exception e) {
	            System.out.println("Erreur lors du dessin d'une forme composante : " + e.getMessage());
	        }
        return segments;
	}

	@Override
	public String typeForme() {
		return "T";
	}

}
